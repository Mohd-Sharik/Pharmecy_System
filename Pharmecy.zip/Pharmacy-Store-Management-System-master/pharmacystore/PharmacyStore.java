
package pharmacystore;


public class PharmacyStore {

    
    public static void main(String[] args) {
       
    }
    
}
